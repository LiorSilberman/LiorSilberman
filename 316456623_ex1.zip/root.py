#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
student: Lior Silberman
id: 316456623
‫‪Assignment‬‬ ‫‪no. 3
Program: root.py‬‬
"""

# get user input
num = float(input("Enter a number: "))
guess_sqrt = float(input("Make a guess: "))
eps = float(input("Enter precision: "))

while guess_sqrt != num**0.5:
    
    # print real root of number before exit
    if abs(guess_sqrt**2-num) < eps:
        print("sqrt({}) = {}".format(num,num**0.5))
        break
        
    # print new average 
    else:
        print(guess_sqrt)
        guess_sqrt = (guess_sqrt+(num/guess_sqrt))/2