#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
student: Lior Silberman
id: 316456623
‫‪Assignment‬‬ ‫‪no. 2
Program: dice.py‬‬
"""

import random

n1 = ["  ----- " , " |     | " , " |  O  | " , " |     | " , "  ----- "]
n2 = ["  ----- " , " |O    | " , " |     | " , " |    O| " , "  ----- "]
n3 = ["  ----- " , " |O    | " , " |  O  | " , " |    O| " , "  ----- "]
n4 = ["  ----- " , " |O   O| " , " |     | " , " |O   O| " , "  ----- "]
n5 = ["  ----- " , " |O   O| " , " |  O  | " , " |O   O| " , "  ----- "]
n6 = ["  ----- " , " |O   O| " , " |O   O| " , " |O   O| " , "  ----- "]    

cubes = [([""], 0) , (n1, 1) , (n2, 2) , (n3, 3) , (n4, 4) , (n5, 5) , (n6, 6) ] 

dice_counter = 0
dice_statistics = {2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0, 10:0, 11:0, 12:0}

while True:
    # get user input
    user_input = input("Press Enter to roll ('q' for EXIT):")

    if user_input != "" or user_input == "q":
        # exit on start?
        if dice_counter == 0:
            print("no dice rolled")
            break
        
        # print dice roll statistics before exit
        for dice, stat in dice_statistics.items():
            print("{}: {} times, {:0.2f}%".format(str(dice), str(stat), (stat/dice_counter)*100))
        break

    # roll two dices
    d1 = cubes[random.randint(1, 6)]
    d2 = cubes[random.randint(1, 6)]

    # print dices to console
    for i in range(5):
        print(d1[0][i], "\t", d2[0][i])
    
    # increase dice roll counter
    dice_counter += 1

    # insert roll result to dice statistics
    dice_statistics[d1[1] + d2[1]] += 1