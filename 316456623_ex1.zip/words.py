#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
student: Lior Silberman
id: 316456623
‫‪Assignment‬‬ ‫‪no. 1
Program: words.py‬‬
"""

# Ask the user to write a sentece, replace white spaces with new line.
print(input("Enter a sentence: ").replace(" ", "\n"))